---
tax-category: "standard-taxable"
_archived: false
_draft: false
created-on: "2021-03-09T18:01:18.479Z"
ec-product-type: "Advanced"
name: "White mountain"
slug: "white-mountain"
shippable: true
updated-on: "2021-03-09T18:39:17.393Z"
default-sku: "site/sku/white-mountain.md"
description: "Un mix aromatico di sapori montani dal sapore agro e fresco. L’eau de parfum dall’agrumato dei fiori di arancio amaro alla freschezza avvolgente del profumo di Tè verde, si sublima con le note calde del legno di sandalo e la dolcezza del muschio. "
category:
  - "site/category/all-perfume.md"
published-on: "2021-03-09T18:16:37.877Z"
tags: "product"
layout: "single-product.html"
---


