---
title: "Order-confirmation"
permalink: "{{ page.fileSlug }}/index.html"
layout: "order-confirmation.html"
slug: "order-confirmation"
tags: "pages"
seo:
  title: "EMME-PERFUME-REDESIGN"
---


